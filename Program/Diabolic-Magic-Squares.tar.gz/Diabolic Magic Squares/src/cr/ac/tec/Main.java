package cr.ac.tec;

public class Main {

    public static void main(String[] args) {
        Frontend.connection(); //his method starts the connection with Prolog.
	    MainScreen.start(); //This method starts the GUI.


    }
}
