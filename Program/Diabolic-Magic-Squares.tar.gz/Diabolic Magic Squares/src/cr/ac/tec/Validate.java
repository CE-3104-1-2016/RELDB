package cr.ac.tec;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by fabian on 03/09/15.
 */
public class Validate {
    private JPanel mainPanel;
    //This text fiels will record the input by the user for the verification of the diabolic magic square
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;
    private JTextField textField5;
    private JTextField textField6;
    private JTextField textField7;
    private JTextField textField8;
    private JTextField textField9;
    private JTextField textField10;
    private JTextField textField11;
    private JTextField textField12;
    private JTextField textField13;
    private JTextField textField14;
    private JTextField textField15;
    private JTextField textField16;
    private JButton validateButton;
    private JButton returnButton;
    private int squareInput[];

    private static JFrame frame;

    private JTextField[][] textFields;

    public static void main() {
        frame = new JFrame("Validate");
        frame.setContentPane(new Validate().mainPanel);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public Validate() {
        //Validate the input was correct
        validateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent actionEvent) {
                squareInput = new int[16];
                JTextField[] textfields = {textField1, textField2, textField3, textField4, textField5,
                        textField6, textField7, textField8, textField9, textField10,textField11,
                        textField12,textField13, textField14, textField15, textField16};

                for (int i = 0; i < textfields.length; i++) {
                    int pos = validateVerification(textfields[i]);
                    if (pos ==-1)break;
                    squareInput[i] = pos;
                }
                System.out.println("\nSquare to validate\n");

                for (int j = 0; j < 16; j++) {
                    System.out.println(squareInput[j]);
                }
                JOptionPane.showMessageDialog(null,Frontend.verifySquare(squareInput));
            }
        });
        returnButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent actionEvent) {
                frame.dispose();
            }
        });
    }



    private void createUIComponents() {


    }

    private int validateVerification(JTextField text){
        int num=0;
        try
        {
            String texto = text.getText();
            if(texto== ""){
                return -1;
            }
            num=Integer.parseInt(texto);
            return num;
        }
        catch(NumberFormatException e)
        {
            //Verifies the input were only numbers
            JOptionPane.showMessageDialog(null,"Error: input not valid, please enter only numbers in the all the fields");
            return -1;
        }

    }

}
