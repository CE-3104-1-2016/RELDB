package cr.ac.tec;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by fabian on 03/09/15.
 */
public class MainScreen {
    private JButton validateButton;
    private JButton generateButton;
    private JButton showallButton;
    private JPanel mainPanel;

    public static void start() { //This method start the GUI
        JFrame frame = new JFrame("MainScreen");
        frame.setContentPane(new MainScreen().mainPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public MainScreen() {
        validateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent actionEvent) {
                Validate.main();
            }
        });//OPens the validate screen
        generateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent actionEvent) {
                Generate.main();

            }
        });//OPens the generate screen
        showallButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent actionEvent) {
                Showall.main(Frontend.showAll());
            }//OPens the showall screen
        });
    }
}
