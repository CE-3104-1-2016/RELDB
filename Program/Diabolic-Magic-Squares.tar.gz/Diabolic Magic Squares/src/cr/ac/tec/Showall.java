package cr.ac.tec;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by fabian on 03/09/15.
 */
public class Showall {
    private JPanel showallPanel;
    private JScrollPane showallScrollPane;
    private JButton returnButton;
    private int matrixesResult[][];


    private static JFrame frame;
    private JPanel panel;


    public Showall(int result [][]) {
        matrixesResult =result;
        returnButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent actionEvent) {
                frame.dispose();
            }
        }); // Closes the frame if the return button is pressed
    }

    public static void main(int result [][]) {

        frame = new JFrame("Showall");
        frame.setContentPane(new Showall(result).showallPanel);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }


    private void createUIComponents() {
        int numRows=(int) Math.ceil(matrixesResult.length/9.0);
        int numColumns= matrixesResult.length/numRows;
        if (numRows*numColumns >= matrixesResult.length){
            numColumns ++;
        }
        panel = new JPanel(new GridLayout(numRows,numColumns,20,20));
        for (int numMatrixes = 0; numMatrixes < matrixesResult.length; numMatrixes++) {

            JPanel matrix= new JPanel(new GridLayout(4,4,2,2));
            for (int item = 0; item < matrixesResult[numMatrixes].length; item++) {
                    JLabel label= new JLabel(""+ matrixesResult[numMatrixes][item]);
                    label.setHorizontalTextPosition(JLabel.LEFT);
                    label.setFont(new Font("Serif", Font.BOLD, 12));
                    matrix.add(label);



            }
            panel.add(matrix);
        }


    }
}

