package cr.ac.tec;

import java.util.Map;
import org.jpl7.*;
/**
 * Created by fabian on 03/09/15.
 */

public class Frontend {

    public static void connection(){ //Enables the connection to Prolog
        Query.hasSolution("use_module(library(jpl))"); // only because we call e.g. jpl_pl_syntax/1 below
        Term swi = Query.oneSolution("current_prolog_flag(version_data,Swi)").get("Swi");
        //
        String t1 = "consult('diabolicMagicSquare-backend.pl')";
        System.out.println(t1 + " " + (Query.hasSolution(t1) ? "succeeded" : "failed"));
    }


    public static boolean verifySquare(int squarelist[]) { //verify the input is actually a diabolic magic square
        Term t = Util.intArrayToList(squarelist);
        Query q = new Query("diabolic", t);
        System.out.println(q.hasSolution());
        return q.hasSolution();
    }

    public static int[][]showAll() { // This method showall the possible diabolic magic sqaure
        Query q = new Query("showall(X)");
        Term[] sols = q.oneSolution().get("X").toTermArray();
        System.out.println("Show all sols: "+ sols.length);
        int[][] results = new int[sols.length][sols[0].toTermArray().length];
        for (int i = 0; i < sols.length; i++) {
            Term[] matrix = sols[i].toTermArray();
            for (int j = 0; j < matrix.length; j++) {
                results[i][j] = matrix[j].intValue();
            }
        }
        return results;
    }
    public static int[][]generate(int number) { // Generates the amount of squares requested
        String query = "diabolic(";
        if(number ==1) query += "A)";else if(number ==2) query += "A,B)";else if(number ==3) query += "A,B,C)";else if(number ==4) query += "A,B,C,D)";
        else if(number ==5) query += "A,B,C,D,E)";else if(number ==6) query += "A,B,C,D,E,F)";else if(number ==7) query += "A,B,C,D,E,F,G)";
        else if(number ==8) query += "A,B,C,D,E,F,G,H)";else if(number ==9) query += "A,B,C,D,E,F,G,H,I)";else if(number ==10) query += "A,B,C,D,E,F,G,H,I,J)";
        int[][] results = new int[number][16];
        Query q = new Query(query);
        String [] opciones = {"A","B","C","D","E","F","G","H","I","J"};
        for (int i = 0; i < number; i++) {
            Term[] matrix = q.oneSolution().get(opciones[i]).toTermArray();
            for (int j = 0; j < matrix.length; j++) {
                results[i][j] = matrix[j].intValue();
            }
        }


        return results;

    }

}


