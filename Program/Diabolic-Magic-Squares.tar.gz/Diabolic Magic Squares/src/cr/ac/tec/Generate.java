package cr.ac.tec;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by fabian on 03/09/15.
 */
public class Generate {
    //Instantiate the several variables
    private JTextField textField1;
    private JPanel generatePanel;
    private JButton generateButton;
    private JButton returnButton;

    private static JFrame frame;


    public static void main() {
        frame = new JFrame("Generate");
        frame.setContentPane(new Generate().generatePanel);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
    public Generate(){
        generateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent actionEvent) {
                int cantidad= 0;
                try { //Validates if the input is not correct.
                    cantidad = Integer.parseInt(textField1.getText());
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null,"Error:input not valid, please enter a number between 1-10");
                }

                if(cantidad>=1 && cantidad<=10){ // Checks that the number is between 1 and 10
                    System.out.println(cantidad);
                    frame.dispose();
                    Showall.main(Frontend.generate(cantidad));
                }
                else{
                    JOptionPane.showMessageDialog(null,"Error: range not valid, please choose from 1-10");
                    frame.dispose();
                }
            }
        });
        returnButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent actionEvent) { //Closes the frame after pressing return
                frame.dispose();
            }
        });
    }
}
